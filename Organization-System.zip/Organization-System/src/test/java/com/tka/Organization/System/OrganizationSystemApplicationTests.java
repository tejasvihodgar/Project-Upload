package com.tka.Organization.System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrganizationSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
