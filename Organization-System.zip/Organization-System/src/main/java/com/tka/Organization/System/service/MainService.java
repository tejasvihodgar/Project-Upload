package com.tka.Organization.System.service;

import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tka.Organization.System.dao.Maindao;
import com.tka.Organization.System.entity.Country;
import com.tka.Organization.System.entity.Employee;

@Service
public class MainService {

	@Autowired
	Maindao dao;

	public String addcountry(Country c) {
		String msg = dao.addcountry(c);
		if (Objects.isNull(msg)) {
			msg = "Country is not added....";
		}

		return msg;

	}

	public String updateCountry(Country c) {
		String msg = dao.updateCountry(c);
		if (Objects.isNull(msg)) {
			msg = "Country is not Updatated....";
		}

		return msg;
	}

	public String deleteCountry(int id) {

		String msg = dao.deleteCountry(id);
		if (Objects.isNull(msg)) {
			msg = "Country is not deleted....";
		}

		return msg;
	}

	public List<Country> getAllCountry() {
		List<Country> list = dao.getAllCountry();

		if (Objects.isNull(list)) {
			list = null;
		}

		return list;
	}

	public Country getCountryById(int id) {
		Country c = dao.getCountryById(id);
		if (Objects.isNull(c)) {
			c = null;
		}

		return c;
	}

	public String addEmployee(Employee emp) {
		String msg = dao.addEmployee(emp);
		if (Objects.isNull(msg)) {
			msg = "Employee is not added...";
		}

		return msg;
	}

	public String updateemployee(Employee c) {
		String msg = dao.updateemployee(c);
		if (Objects.isNull(msg)) {
			msg = "employee is not Updatated....";
		}

		return msg;
	}

	public List<Employee> getAllEmployee() {
		List<Employee> list = dao.getAllEmployee();
		if (Objects.isNull(list)) {
			list = null;
		}

		return list;
	}

	public String deleteemployee(int id) {
		String msg = dao.deleteemployee(id);
		if (Objects.isNull(msg)) {
			msg = "employee is not deleted....";
		}

		return msg;
	}

	public Employee getparticularById(int id) {
		Employee emp = dao.getparticularById(id);

		if (Objects.isNull(emp)) {
			emp = null;
		}

		return emp;
	}

	public List<Employee> getListByStatus(String status) {
		List<Employee> list = dao.getListByStatus(status);
		return list;
	}

	public HashMap loginUser(Employee emp) {
		Employee e = dao.loginUser(emp);
		HashMap map = new HashMap();

		if (Objects.isNull(e)) {
			// invalid user

			map.put("msg", "Invalid User");
			map.put("user", e);

		} else {
			// valid user

			map.put("msg", "valid User");
			map.put("user", e);

		}
		return map;

	}

}
