package com.tka.Organization.System.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tka.Organization.System.entity.Country;
import com.tka.Organization.System.entity.Employee;

@Repository
public class Maindao {

	@Autowired
	SessionFactory factory;

	public String addcountry(Country c) {

		Session session = null;
		Transaction tx = null;
		String msg = null;

		try {
			session = factory.openSession();

			tx = session.beginTransaction();

			session.persist(c);
			tx.commit();
			msg = "Country Added Successfully";

		} catch (Exception e) {
			// TODO: handle exception

			if (tx != null) {
				tx.rollback();
			}

			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return msg;
	}

	public String updateCountry(Country c) {
		Session session = null;
		org.hibernate.Transaction tx = null;
		String msg = null;

		try {
			session = factory.openSession();
			tx = session.beginTransaction();

			Country country = session.get(Country.class, c.getCid());

			country.setCname(c.getCname());
			session.merge(country);
			tx.commit();
			msg = "Country is Updatated Successfully...";

		} catch (Exception e) {
			// TODO: handle exception

			if (tx != null) {
				tx.rollback();
			}

			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}

		return msg;
	}

	public String deleteCountry(int id) {
		Session session = null;
		org.hibernate.Transaction tx = null;
		String msg = null;

		try {
			session = factory.openSession();
			tx = session.beginTransaction();

			Country country = session.get(Country.class, id);

			session.remove(country);

			tx.commit();
			msg = "Country is Deleted Successfully...";

		} catch (Exception e) {
			// TODO: handle exception

			if (tx != null) {
				tx.rollback();
			}

			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}

		return msg;
	}

	public List<Country> getAllCountry() {
		Session session = null;
		org.hibernate.Transaction tx = null;
		List<Country> list = null;
		String hqlQuery = "from Country";

		try {
			session = factory.openSession();
			tx = session.beginTransaction();

			Query<Country> query = session.createQuery(hqlQuery, Country.class);

			list = query.list();
			tx.commit();

		} catch (Exception e) {
			// TODO: handle exception

			if (tx != null) {
				tx.rollback();
			}

			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}

		return list;
	}

	public Country getCountryById(int id) {
		Session session = null;
		org.hibernate.Transaction tx = null;
		Country c = null;

		try {
			session = factory.openSession();
			tx = session.beginTransaction();

			c = session.get(Country.class, id);

			tx.commit();

		} catch (Exception e) {
			// TODO: handle exception

			if (tx != null) {
				tx.rollback();
			}

			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}

		return c;
	}

	public String addEmployee(Employee emp) {
		Session session = null;
		Transaction tx = null;
		String msg = null;

		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			session.persist(emp);
			tx.commit();
			msg = "Employee Added Successfully...";

		} catch (Exception e) {
			// TODO: handle exception

			if (tx != null) {
				tx.rollback();
			}

			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}

		return msg;
	}

	public String updateemployee(Employee c) {
		Session session = null;
		org.hibernate.Transaction tx = null;
		String msg = null;

		try {
			session = factory.openSession();
			tx = session.beginTransaction();

			Employee emp = session.get(Employee.class, c.getId());

			emp.setName(c.getName());
			session.merge(c);
			tx.commit();
			msg = "employee is Updatated Successfully...";

		} catch (Exception e) {
			// TODO: handle exception

			if (tx != null) {
				tx.rollback();
			}

			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}

		return msg;
	}

	public List<Employee> getAllEmployee() {
		Session session = null;
		Transaction tx = null;
		List<Employee> list = null;
		String hqlQuery = "from Employee";

		try {
			session = factory.openSession();
			tx = session.beginTransaction();

			Query<Employee> query = session.createQuery(hqlQuery, Employee.class);

			list = query.list();
			tx.commit();

		} catch (Exception e) {
			// TODO: handle exception

			if (tx != null) {
				tx.rollback();
			}

			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}

		return list;
	}

	public String deleteemployee(int id) {
		Session session = null;
		org.hibernate.Transaction tx = null;
		String msg = null;

		try {
			session = factory.openSession();
			tx = session.beginTransaction();

			Country country = session.get(Country.class, id);

			session.remove(country);

			tx.commit();
			msg = "employee is Deleted Successfully...";

		} catch (Exception e) {
			// TODO: handle exception

			if (tx != null) {
				tx.rollback();
			}

			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}

		return msg;
	}

	public Employee getparticularById(int id) {
		Session session = null;
		Transaction tx = null;
		Employee emp = null;

		try {

			session = factory.openSession();
			tx = session.beginTransaction();

			emp = session.get(Employee.class, id);
			tx.commit();

		} catch (Exception e) {
			// TODO: handle exception
			if (tx != null) {
				tx.rollback();
			}

			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}

		return emp;
	}

	public List<Employee> getListByStatus(String status) {
		Session session = null;
		Transaction tx = null;
		List<Employee> list = null;
		String hqlQuery = "from Employee where status=:status";

		try {

			session = factory.openSession();
			tx = session.beginTransaction();

			Query<Employee> query = session.createQuery(hqlQuery, Employee.class);
			query.setParameter("status", status);

			list = query.list();
			tx.commit();

		} catch (Exception e) {
			// TODO: handle exception

			if (tx != null) {
				tx.rollback();
			}

			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return list;
	}

	public Employee loginUser(Employee emp) {
		// TODO Auto-generated method stub
		Session session = null;
		Transaction tx = null;
		String hqlQuery = "from Employee where name=:name and phoneno=:phoneno";
		Employee employee = null;

		try {

			session = factory.openSession();
			tx = session.beginTransaction();

			Query<Employee> query = session.createQuery(hqlQuery, Employee.class);
			query.setParameter("name", emp.getName());
			query.setParameter("phoneno", emp.getPhoneno());

			employee = query.uniqueResult();

			tx.commit();

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}

		return employee;

	}

}
