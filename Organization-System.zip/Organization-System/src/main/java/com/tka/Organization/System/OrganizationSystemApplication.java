package com.tka.Organization.System;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrganizationSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrganizationSystemApplication.class, args);
		System.out.println("Application started....");
	}

}
